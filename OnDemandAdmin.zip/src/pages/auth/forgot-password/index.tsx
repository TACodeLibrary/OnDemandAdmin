import { Outlet } from 'react-router-dom';


const ForgotPassword = () => {
  return (
    <Outlet/>
  )
}

export default ForgotPassword